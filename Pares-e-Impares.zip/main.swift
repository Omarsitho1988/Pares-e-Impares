var numero: Int;

print("dame un numero: ",
      terminator: "")
numero = Int (readLine()!)!

if numero % 2 == 0 {
  print ("\(numero) es par")
}
else {
  print("\(numero) es impar")
}